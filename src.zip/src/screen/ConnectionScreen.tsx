import { FC } from 'react';
import { View, Text } from 'react-native';

const ConnectionScreen:FC = () => {
    return (
        <View>
            <Text>ConnectionScreen</Text>
        </View>
    )
}

export default ConnectionScreen;