import { View, Text } from 'react-native'

function SendScreen() {
  return (
    <View>
      <Text>SendScreen</Text>
    </View>
  )
}

export default SendScreen;